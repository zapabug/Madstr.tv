package com.madstr.tvapp;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
