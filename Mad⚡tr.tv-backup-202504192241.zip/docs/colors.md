Purple Scale:
purple-50: #faf5ff (Very light purple)
purple-100: #f3e8ff
purple-200: #e9d5ff
purple-300: #d8b4fe (You're using this for focus)
purple-400: #c084fc (You're using this for focus)
purple-500: #a855f7
purple-600: #9333ea (Your current main purple)
purple-700: #7e22ce
purple-800: #6b21a8
purple-900: #581c87
purple-950: #3b0764 (Very dark purple)
Violet Scale:
violet-50: #f5f3ff (Very light violet)
violet-100: #ede9fe
violet-200: #ddd6fe
violet-300: #c4b5fd
violet-400: #a78bfa
violet-500: #8b5cf6 (Often a popular, bright choice)
violet-600: #7c3aed
violet-700: #6d28d9
violet-800: #5b21b6
violet-900: #4c1d95
violet-950: #2e1065 (Very dark violet)