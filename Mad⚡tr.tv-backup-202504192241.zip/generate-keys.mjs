import { generateSecretKey, getPublicKey } from 'nostr-tools/pure'
import { nip19 } from 'nostr-tools' // nip19 is likely still in the main export
import { bytesToHex } from '@noble/hashes/utils' // Need this to potentially view the hex version if needed

const sk_bytes = generateSecretKey() // `sk_bytes` is a Uint8Array
const pk_hex = getPublicKey(sk_bytes) // `pk_hex` is a hex string

// nsecEncode expects the Uint8Array secret key
const nsec = nip19.nsecEncode(sk_bytes)
const npub = nip19.npubEncode(pk_hex)

console.log('Private Key (nsec):', nsec);
console.log('Public Key (npub):', npub);
// Optional: log raw hex keys if needed
// console.log('Private Key (hex):', bytesToHex(sk_bytes));
// console.log('Public Key (hex):', pk_hex); 