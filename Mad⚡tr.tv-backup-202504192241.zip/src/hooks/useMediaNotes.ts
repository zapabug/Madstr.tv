import { useState, useEffect, useRef, useCallback } from 'react';
import NDK, { NDKEvent, NDKFilter, NDKSubscription } from '@nostr-dev-kit/ndk';
import { NostrNote } from '../types/nostr';
import { cacheMediaNotes, getCachedNotesByAuthors } from '../utils/mediaNoteCache';

// Define media types
export type MediaType = 'podcast' | 'video' | 'image';

// Define hook props
interface UseMediaNotesProps {
    authors: string[];
    mediaType: MediaType;
    ndk: NDK | null;
    limit?: number; // <<< Renamed from initialLimit, now dynamic
    until?: number; // <<< Added until timestamp (seconds)
    followedTags?: string[]; // <<< Add optional followedTags
}

// Define hook return value
interface UseMediaNotesReturn {
    notes: NostrNote[];
    isLoading: boolean;
    fetchOlderNotes?: () => void; // <<< Optional: Expose a direct fetch function? No, let App control via props.
}

// Regexes (consider moving to constants or utils)
const imageRegex = /https?:\/\/\S+\.(?:png|jpg|jpeg|gif|webp)/i;
const videoRegex = /https?:\/\/\S+\.(?:mp4|mov|webm|m3u8)/i;
const audioRegex = /https?:\/\/\S+\.(?:mp3|m4a|ogg|aac|wav)/i;

// Helper to get Kinds based on MediaType
function getKindsForMediaType(mediaType: MediaType): number[] {
    switch (mediaType) {
        case 'podcast': return [30402, 1, 31234]; // NIP-101 + Kind 1 fallback + User's Kind
        case 'video': return [1]; // Primarily Kind 1 for simple links
        case 'image': return [1]; // Primarily Kind 1 for simple links
        default: return [1];
    }
}

// Helper to get URL Regex based on MediaType
function getUrlRegexForMediaType(mediaType: MediaType): RegExp {
    switch (mediaType) {
        case 'podcast': return audioRegex;
        case 'video': return videoRegex;
        case 'image': return imageRegex;
        default: return /https?:\/\/\S+/i; // Generic fallback
    }
}

export function useMediaNotes({
    authors,
    mediaType,
    ndk,
    limit = 200, // Default limit if not provided
    until,       // Use provided until timestamp
    followedTags, // <<< Destructure followedTags prop
}: UseMediaNotesProps): UseMediaNotesReturn {
    const [notes, setNotes] = useState<NostrNote[]>([]);
    const [isLoading, setIsLoading] = useState<boolean>(true);
    // notesById now accumulates across fetches triggered by prop changes
    const notesById = useRef<Map<string, NostrNote>>(new Map());
    const currentSubscription = useRef<NDKSubscription | null>(null);
    const isFetching = useRef<boolean>(false); // Prevent concurrent fetches
    // Add refs to track previous dependency values
    const prevNdkRef = useRef<NDK | null>(ndk);
    const prevAuthorsRef = useRef<string[]>(authors);
    const prevMediaTypeRef = useRef<MediaType>(mediaType);
    const prevLimitRef = useRef<number>(limit);
    const prevUntilRef = useRef<number | undefined>(until);
    const prevFollowedTagsRef = useRef<string[] | undefined>(followedTags);

    // <<< Add logging for image type specifically >>>
    if (mediaType === 'image') {
        console.log("useMediaNotes (image): Hook rendering/re-rendering.", { authors, limit, until, followedTags });
    }

    const processEvent = useCallback((event: NDKEvent, _urlRegex: RegExp, type: MediaType): NostrNote | null => {
        const urlRegex = getUrlRegexForMediaType(type);
        if (type === 'image') {
            console.log(`processEvent (image): Checking event ${event.id}`, { content: event.content.substring(0, 100), tags: event.tags });
        }

        let mediaUrl: string | undefined;
        let foundVia: string | null = null;

        // --- Prioritize specific tags based on type --- 
        
        if (type === 'image') {
            // 1. Prioritize 'image' tag for images
            const imageTag = event.tags.find((t) => t[0] === 'image');
            if (imageTag && imageTag[1]?.match(urlRegex)) {
                mediaUrl = imageTag[1];
                foundVia = 'image tag';
            }
            // 2. Check 'url' tag for image types
            if (!mediaUrl) {
                 const urlTag = event.tags.find((t) => t[0] === 'url');
                 if (urlTag && urlTag[1]?.match(urlRegex)) {
                     mediaUrl = urlTag[1];
                     foundVia = 'url tag + image regex';
                 }
            }
            // 3. Check 'media' tag for image types
            if (!mediaUrl) {
                 const mediaTag = event.tags.find((t) => t[0] === 'media');
                 if (mediaTag && mediaTag[1]?.match(urlRegex)) {
                     mediaUrl = mediaTag[1];
                     foundVia = 'media tag + image regex';
                 }
            }
            // 4. Check for image MIME type ('m' tag) + associated 'url' tag
            if (!mediaUrl) {
                 const mimeTag = event.tags.find((t) => t[0] === 'm' && t[1]?.startsWith('image/'));
                 if (mimeTag) {
                     const associatedUrlTag = event.tags.find((t) => t[0] === 'url');
                     if (associatedUrlTag && associatedUrlTag[1]?.match(urlRegex)) {
                         mediaUrl = associatedUrlTag[1];
                         foundVia = 'm tag (image) + url tag';
                     }
                 }
            }
        } else if (type === 'video') {
            // Video logic (prioritizing mime type first, then url/media)
            const mimeTag = event.tags.find((t) => t[0] === 'm' && t[1]?.startsWith('video/'));
            if (mimeTag) {
                 foundVia = 'm tag (video)';
                 const urlTag = event.tags.find((t) => t[0] === 'url');
                 if (urlTag && urlTag[1]) { mediaUrl = urlTag[1]; foundVia += ' + url tag'; }
                 if (!mediaUrl) {
                     const mediaTag = event.tags.find((t) => t[0] === 'media');
                     if (mediaTag && mediaTag[1]) { mediaUrl = mediaTag[1]; foundVia += ' + media tag'; }
                 }
                 // Only fallback to content regex if video mime type was found but no URL tag
                 if (!mediaUrl) {
                     const genericUrlRegex = /https?:\/\/\S+/i;
                     const contentMatch = event.content.match(genericUrlRegex);
                     if (contentMatch) { mediaUrl = contentMatch[0]; foundVia += ' + content regex fallback'; }
                 }
            } else {
                 // Fallback checks if no video mime type
                 const urlTag = event.tags.find((t) => t[0] === 'url');
                 if (urlTag && urlTag[1]?.match(urlRegex)) { mediaUrl = urlTag[1]; foundVia = 'url tag + video regex'; }
                 if (!mediaUrl) {
                     const mediaTag = event.tags.find((t) => t[0] === 'media');
                     if (mediaTag && mediaTag[1]?.match(urlRegex)) { mediaUrl = mediaTag[1]; foundVia = 'media tag + video regex'; }
                 }
            }
        } else if (type === 'podcast') {
            // Podcast logic (prioritizing enclosure, then url/media)
            const enclosureTag = event.tags.find((t) => t[0] === 'enclosure');
            if (enclosureTag && enclosureTag[1]?.match(urlRegex)) { mediaUrl = enclosureTag[1]; foundVia = 'enclosure tag'; }
            if (!mediaUrl) {
                 const urlTag = event.tags.find((t) => t[0] === 'url');
                 if (urlTag && urlTag[1]?.match(urlRegex)) { mediaUrl = urlTag[1]; foundVia = 'url tag + audio regex'; }
            }
            if (!mediaUrl) {
                 const mediaTag = event.tags.find((t) => t[0] === 'media');
                 if (mediaTag && mediaTag[1]?.match(urlRegex)) { mediaUrl = mediaTag[1]; foundVia = 'media tag + audio regex'; }
            }
        }

        // --- Fallback to content regex LAST for all types --- 
        if (!mediaUrl) {
            const contentMatch = event.content.match(urlRegex);
            if (contentMatch) {
                mediaUrl = contentMatch[0];
                foundVia = 'content regex fallback';
                console.log(`processEvent (${type}): URL found via CONTENT REGEX fallback for event ${event.id}`);
            }
        }

        // --- End of URL Finding Logic --- 

        if (!mediaUrl) {
            if (type === 'image') {
                console.log(`processEvent (image): Skipping event ${event.id} - No valid URL found in tags or content.`);
            }
            return null;
        } else {
            if (type === 'image') {
                 console.log(`processEvent (image): Found URL for event ${event.id} via ${foundVia}. URL: ${mediaUrl}`);
            }
        }

        // 2. Extract Metadata (Example)
        const title = event.tags.find(t => t[0] === 'title')?.[1];
        const summary = event.tags.find(t => t[0] === 'summary')?.[1];
        const image = event.tags.find(t => t[0] === 'image')?.[1]; // Cover art
        const duration = event.tags.find(t => t[0] === 'duration')?.[1];

        const note: NostrNote = {
            id: event.id,
            pubkey: event.pubkey,
            created_at: event.created_at ?? 0,
            kind: event.kind ?? 0,
            tags: event.tags,
            content: event.content,
            sig: event.sig || '',
            url: mediaUrl,
            posterPubkey: event.pubkey,
            // Add extracted metadata
            title: title,
            summary: summary,
            image: image,
            duration: duration,
        };
        return note;

    }, []); // No dependencies, it's a pure function based on args

    useEffect(() => {
        // --- Dependency Change Logging --- 
        let changedDeps: string[] = [];
        if (prevNdkRef.current !== ndk) changedDeps.push('ndk');
        // Shallow compare arrays for changes
        if (JSON.stringify(prevAuthorsRef.current) !== JSON.stringify(authors)) {
            changedDeps.push('authors');
            if (mediaType === 'image') {
                console.log(`useMediaNotes (image): ** Authors prop changed! ** Prev: ${prevAuthorsRef.current?.length ?? 0}, New: ${authors.length}`);
            }
        }
        if (prevMediaTypeRef.current !== mediaType) changedDeps.push('mediaType');
        if (prevLimitRef.current !== limit) changedDeps.push('limit');
        if (prevUntilRef.current !== until) changedDeps.push('until');
        if (JSON.stringify(prevFollowedTagsRef.current) !== JSON.stringify(followedTags)) changedDeps.push('followedTags');
        
        if (mediaType === 'image') {
             if (changedDeps.length > 0) {
                 console.log(`useMediaNotes (image): Effect triggered by changed dependencies:`, changedDeps.join(', '));
             }
             console.log(`useMediaNotes (image): Effect check`, { isFetching: isFetching.current, hasNdk: !!ndk, numAuthors: authors.length });
        }
        // Update previous value refs *after* comparison
        prevNdkRef.current = ndk;
        prevAuthorsRef.current = authors;
        prevMediaTypeRef.current = mediaType;
        prevLimitRef.current = limit;
        prevUntilRef.current = until;
        prevFollowedTagsRef.current = followedTags;
        // ---------------------------------

        // Debounce or prevent fetch if already fetching or no NDK/authors
        if (isFetching.current || !ndk || authors.length === 0) {
            // If no authors/ndk, clear state
            if (!ndk || authors.length === 0) {
                 setNotes([]);
                 notesById.current.clear(); // Clear map if authors/ndk removed
                 setIsLoading(false);
            }
            return; 
        }

        let isMounted = true;
        // Do NOT clear notesById.current here - we want to accumulate
        setIsLoading(true);
        isFetching.current = true; // Mark as fetching
        // Don't clear displayed notes immediately unless authors/type changed significantly?
        // Maybe only clear if until is undefined (meaning a fresh load)?
        // For simplicity, let's keep existing notes displayed while loading more.

        const authorsList = authors;
        const kindsToFetch = getKindsForMediaType(mediaType);
        const urlRegex = getUrlRegexForMediaType(mediaType);

        const fetchAndSubscribe = async () => {
            // ... cache check ...
            if (mediaType === 'image') {
                console.log(`useMediaNotes (image): Checking cache for ${authorsList.length} authors.`);
                // Add more detail on cache results if needed
            }
            
            // --- Cache Check (Always read and merge) ---
            console.log(`useMediaNotes (${mediaType}): Checking cache for ${authorsList.length} authors.`);
            // <<< Always try to load from cache >>>
            const cachedNotes = await getCachedNotesByAuthors(authorsList);
            console.log(`useMediaNotes (${mediaType}): Raw cached notes found: ${cachedNotes.length}`); 
            const relevantCachedNotes: NostrNote[] = [];
            let newNotesAddedFromCache = false;
            if (cachedNotes.length > 0) {
                cachedNotes.forEach(note => {
                    // Filter for relevance (kind, matching URL regex for the *current* mediaType)
                    if (kindsToFetch.includes(note.kind) && note.url && note.url.match(urlRegex)) { 
                        if (!notesById.current.has(note.id)) {
                            notesById.current.set(note.id, note);
                            relevantCachedNotes.push(note);
                            newNotesAddedFromCache = true;
                        }    
                    } 
                });
                if (newNotesAddedFromCache) {
                    console.log(`useMediaNotes (${mediaType}): Added ${relevantCachedNotes.length} relevant notes from cache to map.`); 
                    // <<< Update UI immediately with combined notes from map >>>
                    const allNotesFromMap = Array.from(notesById.current.values());
                    const sortedNotes = allNotesFromMap.sort((a, b) => b.created_at - a.created_at);
                    if (isMounted) {
                        console.log(`useMediaNotes (${mediaType}): Updating state immediately with ${sortedNotes.length} notes from cache/map.`);
                        setNotes(sortedNotes); 
                        // Maybe set isLoading false briefly if only cache was hit?
                        // setIsLoading(false); // Consider implications
                    }
                } else {
                    console.log(`useMediaNotes (${mediaType}): No *new* relevant notes found in cache after filtering.`);
                }
            } else {
                 console.log(`useMediaNotes (${mediaType}): Cache was empty for these authors.`);
            }
            // <<< End of modified cache handling >>>
            
            // --- Subscription --- 
            const filter: NDKFilter = {
                kinds: kindsToFetch,
                authors: authorsList,
                limit: limit,
            };
            if (until !== undefined) {
                filter.until = until;
            }
            if (followedTags && followedTags.length > 0) {
                filter['#t'] = followedTags.map(tag => tag.toLowerCase()); 
            }

            // <<< Moved logging after filter definition >>>
            if (mediaType === 'image') {
                 console.log(`useMediaNotes (image): Subscribing (Kinds: ${kindsToFetch}, Limit: ${limit}, Until: ${until ? new Date(until * 1000).toISOString() : 'N/A'})...`);
                 if (filter['#t']) console.log(`useMediaNotes (image): Filtering by tags:`, filter['#t']);
            }
            
            // Stop previous subscription if it exists
            if (currentSubscription.current) {
                currentSubscription.current.stop();
            }
            
            currentSubscription.current = ndk.subscribe(filter, { closeOnEose: false, groupable: false });

            currentSubscription.current.on('event', (event: NDKEvent) => {
                const note = processEvent(event, urlRegex, mediaType);
                if (note && !notesById.current.has(note.id)) {
                    // <<< Log note add >>>
                    if (mediaType === 'image') {
                         console.log(`useMediaNotes (image): Adding new note ${note.id} from WS to internal map.`);
                    }
                    notesById.current.set(note.id, note);
                }
            });

            currentSubscription.current.on('eose', () => {
                if (mediaType === 'image') {
                    console.log(`useMediaNotes (image): EOSE received. Total notes in map: ${notesById.current.size}`);
                }
                const finalNotes = Array.from(notesById.current.values());
                const sortedFinalNotes = finalNotes.sort((a, b) => b.created_at - a.created_at);
                if (isMounted) {
                    // <<< Log final state update >>>
                    if (mediaType === 'image') {
                        console.log(`useMediaNotes (image): Updating state with ${sortedFinalNotes.length} notes after EOSE.`);
                    }
                    setNotes(sortedFinalNotes);
                    setIsLoading(false);
                    isFetching.current = false;
                }
                // Cache the final accumulated notes
                console.log(`useMediaNotes (${mediaType}): Caching ${finalNotes.length} notes after EOSE.`);
                cacheMediaNotes(finalNotes).catch(error => {
                     console.error(`useMediaNotes (${mediaType}): Error caching notes after EOSE:`, error);
                });
            });
        };

        fetchAndSubscribe().catch(err => {
            console.error(`useMediaNotes (${mediaType}): Error fetching notes:`, err);
            if (isMounted) {
                 setIsLoading(false);
                 isFetching.current = false; // Mark fetching complete on error
            }
        });

        // Cleanup
        return () => {
            isMounted = false;
            if (currentSubscription.current) {
                console.log(`useMediaNotes (${mediaType}): Cleaning up subscription.`);
                currentSubscription.current.stop();
                currentSubscription.current = null;
            }
            isFetching.current = false; // Ensure fetching flag is reset if component unmounts during fetch
        };
    // Re-run effect if ndk, authors, mediaType, limit, or until changes
    }, [ndk, authors, mediaType, limit, until, followedTags, processEvent]); // <<< Add followedTags to dependency array

    // <<< Log return value >>>
    if (mediaType === 'image') {
        console.log(`useMediaNotes (image): Returning state`, { notesLength: notes.length, isLoading });
    }
    return {
        notes,
        isLoading,
    };
} 