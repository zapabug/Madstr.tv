import NDK, { NDKEvent } from '@nostr-dev-kit/ndk';

// --- TV App's Public Identity ---
// Still needed for reference or other parts of the app
export const TV_PUBKEY_HEX = "3b6e10bfa01046da7a16af797e56f7734a84c2564d9c0c51a04f675509514669";
// ----------------------------------

// --- Signer-related functions removed ---